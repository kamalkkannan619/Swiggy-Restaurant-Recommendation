# Swiggy Restaurant Recommendation System 🍴

## Overview
A Streamlit-based app that recommends restaurants based on user preferences (city, cuisine, rating, cost).

## Steps
1. Run `cleaning.py` → generates cleaned_data.csv
2. Run `encoding.py` → generates encoded_data.csv + encoder.pkl
3. Run `recommendation.py` → test recommendation logic
4. Run `app.py` → launch Streamlit app

## How to Run
```bash
streamlit run app.py
