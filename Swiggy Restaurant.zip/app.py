import streamlit as st
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# Load datasets
cleaned_df = pd.read_csv("cleaned_data.csv")
encoded_df = pd.read_csv("encoded_data.csv")

# Recommendation function
def recommend(city, cuisine, rating, cost, top_n=5):
    user_input = pd.DataFrame([[rating, 0, cost]], columns=['rating','rating_count','cost'])
    
    # Add encoded city & cuisine
    for col in encoded_df.columns:
        if col.startswith("city_"):
            user_input[col] = 1 if col == f"city_{city}" else 0
        elif col.startswith("cuisine_"):
            user_input[col] = 1 if col == f"cuisine_{cuisine}" else 0
    
    sim_scores = cosine_similarity(user_input, encoded_df)[0]
    top_indices = sim_scores.argsort()[-top_n:][::-1]
    return cleaned_df.iloc[top_indices][['name','city','rating','cost','cuisine','address']]

# Streamlit UI
st.title("🍴 Swiggy Restaurant Recommendation System")

city = st.selectbox("Select City", cleaned_df['city'].unique())
cuisine = st.selectbox("Select Cuisine", cleaned_df['cuisine'].unique())
rating = st.slider("Minimum Rating", 0.0, 5.0, 4.0)
cost = st.number_input("Approximate Cost", min_value=100, max_value=1000, value=300)

if st.button("Get Recommendations"):
    results = recommend(city, cuisine, rating, cost)
    st.write("### Recommended Restaurants")
    st.dataframe(results)
