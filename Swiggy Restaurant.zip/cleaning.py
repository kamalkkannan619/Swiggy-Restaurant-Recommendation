import pandas as pd

# 1. Load the dataset
df = pd.read_csv("restaurants.csv")

# 2. Show first 5 rows
print("First 5 rows of data:")
print(df.head())

# 3. Remove duplicate rows
df = df.drop_duplicates()

# 4. Handle missing values
df['rating'] = df['rating'].fillna(df['rating'].mean())
df['cost'] = df['cost'].fillna(df['cost'].median())
df['city'] = df['city'].fillna(df['city'].mode()[0])
df['cuisine'] = df['cuisine'].fillna(df['cuisine'].mode()[0])

# 5. Save cleaned dataset
df.to_csv("cleaned_data.csv", index=False)

print("✅ Cleaned data saved as cleaned_data.csv")
