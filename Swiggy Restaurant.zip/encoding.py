import pandas as pd
from sklearn.preprocessing import OneHotEncoder
import pickle

df = pd.read_csv("cleaned_data.csv")

categorical_cols = ['city', 'cuisine']

# ✅ Fixed parameter name
encoder = OneHotEncoder(sparse_output=False)
encoded_array = encoder.fit_transform(df[categorical_cols])

encoded_df = pd.DataFrame(encoded_array, columns=encoder.get_feature_names_out(categorical_cols))

numerical_cols = ['rating', 'rating_count', 'cost']
final_df = pd.concat([df[numerical_cols], encoded_df], axis=1)

final_df.to_csv("encoded_data.csv", index=False)

with open("encoder.pkl", "wb") as f:
    pickle.dump(encoder, f)

print("✅ Encoded data saved as encoded_data.csv")
print("✅ Encoder saved as encoder.pkl")
