import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# 1. Load datasets
cleaned_df = pd.read_csv("cleaned_data.csv")
encoded_df = pd.read_csv("encoded_data.csv")

# 2. Function to recommend restaurants
def recommend(city, cuisine, rating, cost, top_n=5):
    # Create input vector
    user_input = pd.DataFrame([[rating, 0, cost]], columns=['rating','rating_count','cost'])
    
    # Add encoded city & cuisine columns
    for col in encoded_df.columns:
        if col.startswith("city_"):
            user_input[col] = 1 if col == f"city_{city}" else 0
        elif col.startswith("cuisine_"):
            user_input[col] = 1 if col == f"cuisine_{cuisine}" else 0
    
    # Compute similarity
    sim_scores = cosine_similarity(user_input, encoded_df)[0]
    
    # Get top N indices
    top_indices = sim_scores.argsort()[-top_n:][::-1]
    
    return cleaned_df.iloc[top_indices][['name','city','rating','cost','cuisine','address']]

# 3. Example usage
print(recommend("Chennai","South Indian",4.5,300))
